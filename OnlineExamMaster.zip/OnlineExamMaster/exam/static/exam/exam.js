document.getElementById("2").style.display = "none";

function myFunction() {
  document.getElementById("2").style.display = "none";
    alert("Hello! I am an alert box!");
  }